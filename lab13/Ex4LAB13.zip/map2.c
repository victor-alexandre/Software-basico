int f(int x);
void map2(int *um, int *outro, int n) {
 int i;
 for (i = 0; i < n; i++)
 *(outro+i) = f( *(um+i) );
}
